package Ejercicio1;

public class Empleado extends Persona {

	public Empleado(String nombre, String apellido, int edad) {
		
		super(nombre, apellido, edad);
	}
	
}