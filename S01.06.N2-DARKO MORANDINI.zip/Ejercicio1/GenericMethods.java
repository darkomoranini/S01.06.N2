package Ejercicio1;

public class GenericMethods<T> {

	private T primero;

	public GenericMethods(){
		
		primero=null;
	}

	public void setPrimero(T nuevoValor) {

		primero=nuevoValor;
	}

	public T getPrimero() {

		return primero; 
	}
	
	public static <T, U, V> void imprimir(T arg1, U arg2, V arg3) {

		String arg2String = arg2.toString();
		System.out.println(arg1+"/"+arg2String+"/"+arg3);
	}
}