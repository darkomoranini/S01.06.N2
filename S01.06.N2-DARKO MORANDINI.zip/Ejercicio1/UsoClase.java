package Ejercicio1;

public class UsoClase {

	public static void main(String[] Args) {
		
		GenericMethods<Persona> primer = new GenericMethods<Persona>();
		
		primer.setPrimero(new Persona("Darko", "Morandini", 28));
		
		System.out.println(primer.getPrimero().toString());
		
		GenericMethods.imprimir(primer.getPrimero().toString(), "------------->", 0100101101);
		
		GenericMethods.imprimir(0100101101, primer.toString(), "------------->");
		
		GenericMethods.imprimir(new Empleado("Ana", "Harrison", 27), "------------->", 0100101101);
			
		}
	}

