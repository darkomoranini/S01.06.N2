package Ejercicio2;

public class GenericMethods<T> {

	private T primero;

	public GenericMethods(){
		
		primero=null;
	}

	public void setPrimero(T nuevoValor) {

		primero=nuevoValor;
	}

	public T getPrimero() {

		return primero; 
	}
	
	
	@SafeVarargs
	public static <T> void imprimir(T... args) {
	    for (T arg : args) {
	        System.out.print(arg + "/");
	    }
	    System.out.println();
	}
}